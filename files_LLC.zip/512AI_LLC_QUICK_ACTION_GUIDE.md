# 512AI LLC Formation - Quick Action Guide

**Goal:** Form 512 Automated Intelligence, LLC in Texas within 2 weeks  
**Cost:** $308 (one-time SOS filing fee)  
**Timeline:** 14 calendar days

---

## DAY 1 - TODAY

**1. Verify Entity Name**
```
Name: 512 Automated Intelligence, LLC
Search: https://mycpa.cpa.state.tx.us/cpaonline/nonpublicdirectsearch/
Backup names: 512AI LLC, Five-Twelve Automated Intelligence LLC
```
✓ Estimated time: 5 min

**2. Set Up Business Email**
```
Email: ricardo@512ai.co (use this for ALL official docs)
Domain: 512ai.co (already registered)
Action: Create email account in your email provider
```
✓ Estimated time: 10 min

**3. Create SOSDirect Account**
```
URL: https://sos.texas.gov/
Create account with business email (ricardo@512ai.co)
Save login credentials
```
✓ Estimated time: 5 min

---

## DAY 2-3 - FILE WITH TEXAS SOS

**4. Prepare Form 205 (Certificate of Formation)**

Required Info:
- Entity Name: 512 Automated Intelligence, LLC
- Type: Limited Liability Company
- Management: Member-Managed
- Registered Agent: You (Ricardo [Last Name])
- Agent Address: [Your 78739 Austin address]
- Principal Place of Business: [Same address]
- Initial Mailing Address: [Your address]
- Organizer: [Your legal name, phone, email - ricardo@512ai.co]

**5. File Online**
```
Login to SOSDirect: https://sos.texas.gov/
Select "File a New Document"
Choose "Limited Liability Company - Certificate of Formation"
Fill out Form 205 (online form)
Upload any required documents
Pay $308 (credit card fee included)
Submit
```

**What You'll Receive:**
- Confirmation email (within 24 hours)
- File-stamped Certificate of Formation (10-12 business days)
- **SAVE THIS DOCUMENT** - needed for EIN + bank account

✓ Estimated time: 30 min filing (then 10-12 days for approval)

---

## DAY 13-14 (After SOS Approval Email)

**6. Apply for EIN (IRS)**
```
URL: https://www.irs.gov/ein
Time: ~5-10 minutes
Get EIN immediately (same day)
```

**What You'll Need:**
- Certificate of Formation (copy from email)
- Business email: ricardo@512ai.co
- Your legal name & SSN
- Address: 78739
- NAICS Code: 541511 (Custom Computer Programming Services)

**7. Register for Texas Taxes**
```
URL: https://webfile.comptroller.texas.gov/
File Franchise Tax Return (even if not owing yet)
Register for Sales Tax Permit (SaaS is taxable in Texas)
Time: 15 min total
```

**8. Open Business Bank Account**
```
Documents needed:
- Certificate of Formation (approved)
- EIN letter (from IRS email)
- Your ID
- Business email

Recommended: Chase, Capital One 360, or Amplify Credit Union
Time to open: 24-48 hours
```

**9. File BOI Report (FinCEN)**
```
DEADLINE: 30 days after SOS approval (around May 5, 2026)
URL: https://www.fincen.gov/boi
Time: 10 minutes
Cost: $0
CRITICAL: $591/day penalty if missed
```

---

## OPTIONAL (But Recommended)

**10. Create Operating Agreement**
```
Single-member LLC agreement
Keep on file (don't submit to SOS)
Template: Legal templates online (~$50-100) or write simple 2-3 pager
Time: 1-2 hours if DIY, 1 hour if using template
```

**11. Get Business Insurance**
```
General Liability + E&O (Professional Liability)
Cost: $500-1000/year
Provider: Hiscox, CoverWallet
Time to bind: 1-2 weeks
```

---

## FINAL CHECKLIST

**Before Filing SOS:**
- [ ] Entity name verified as available
- [ ] Business email created (ricardo@512ai.co)
- [ ] SOSDirect account created
- [ ] All Form 205 info gathered

**After SOS Approval (10-12 days later):**
- [ ] EIN applied for (same day)
- [ ] Franchise Tax registered
- [ ] Sales Tax Permit registered
- [ ] Business bank account opened
- [ ] BOI Report filed (within 30 days)
- [ ] Operating Agreement created (optional but do it)

**Success Criteria:**
- ✓ 512 Automated Intelligence, LLC registered with Texas
- ✓ EIN issued by IRS
- ✓ Business bank account active
- ✓ Compliant with franchise & sales tax
- ✓ BOI filed with FinCEN

---

## ONGOING (Monthly/Yearly)

**Monthly:**
- Track SaaS revenue for sales tax (if you registered for it)

**Quarterly/Yearly:**
- File sales tax return (if applicable)

**By December 15 Annually:**
- File Franchise Tax Return with Texas Comptroller

**By April 15 Annually:**
- File personal tax return with Schedule C (IRS) showing LLC income

---

## CRITICAL MISTAKES TO AVOID

❌ Using personal bank account for business transactions  
❌ Filing without business email (misses official notices)  
❌ Missing BOI deadline (May 5, 2026 - $591/day penalty)  
❌ Not registering for sales tax (if you have Texas customers)  
❌ Forgetting to keep Certificate of Formation copy  

---

## NEED HELP?

**If SOS filing rejected:**
- Check entity name isn't already taken
- Verify all required fields are filled
- Resubmit with corrected info

**If EIN doesn't arrive within 5 business days:**
- Check spam folder for IRS email
- Call IRS: 1-800-829-3676

**If sales tax rate unclear:**
- Email: Texas Comptroller at (512) 463-4600
- Or check: https://webfile.comptroller.texas.gov/

**For legal questions:**
- Austin SBDC: Free advising at https://www.austinsbdc.org
- SCORE Austin: Free mentoring at https://www.score.org

---

**Start Date:** April 5, 2026  
**Expected Completion:** April 19, 2026 (if everything proceeds on schedule)  
**Stay on track:** Check this daily until SOS approval
